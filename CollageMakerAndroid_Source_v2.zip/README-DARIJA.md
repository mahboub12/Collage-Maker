# Collage Maker — Android source project

هاد مشروع Android أولي مكتوب بـ Kotlin وJetpack Compose. كيتيح:
- اختيار حتى 9 صور من الهاتف.
- معاينة الصور فـ grid.
- تركيب الصور فصورة واحدة وحفظها فـ Pictures/CollageMaker.
- مشاركة الصورة.

## كيفاش تبنيه من الهاتف
1. نزّل ZIP ديال المشروع وفك الضغط عليه.
2. أنشئ repository جديد فـ GitHub من المتصفح.
3. طلّع جميع الملفات والمجلدات ديال المشروع للـ repository وخلي اسم الفرع `main`.
4. افتح تبويب Actions ووافق على تشغيل GitHub Actions إذا طلب منك.
5. انتظر حتى ينجح `Build Collage Maker`.
6. افتح run الناجح، ومن Artifacts نزّل `CollageMaker-debug-apk` للتجربة.

مهم:
- هاد الملف كيعطي APK للتجربة فقط، ماشي ملف نشر نهائي.
- قبل Google Play خاصنا نوجدوا signing key ونسخة release AAB، ونختبرو التطبيق ونراجعوا سياسة المتجر.
- ما ترفعش passwords أو keystore secrets داخل الكود أو repository.
- المشروع الأولي خاصو يتبنى ويتجرب قبل اعتباره جاهز للنشر.

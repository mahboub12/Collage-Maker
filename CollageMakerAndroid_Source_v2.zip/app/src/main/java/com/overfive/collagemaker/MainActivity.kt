package com.overfive.collagemaker

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Paint
import android.graphics.Rect
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.Context
import java.io.OutputStream

private val Ink = Color(0xFF10111B)
private val Panel = Color(0xFF1C1D2B)
private val Purple = Color(0xFF8B5CF6)
private val SoftText = Color(0xFFB8B8CA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple,
                background = Ink,
                surface = Panel,
                onBackground = Color.White,
                onSurface = Color.White
            )) {
                CollageHome()
            }
        }
    }
}

@Composable
private fun CollageHome() {
    val context = LocalContext.current
    var photos by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var savedUri by remember { mutableStateOf<Uri?>(null) }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetMultipleContents()
    ) { selected ->
        photos = selected.take(9)
        savedUri = null
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Ink) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text("PHOTO STUDIO", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
            Spacer(Modifier.height(8.dp))
            Text("Collage Maker", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text("Turn your favorite moments into one beautiful picture.", color = SoftText, fontSize = 14.sp)
            Spacer(Modifier.height(20.dp))

            Button(
                onClick = { picker.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                androidx.compose.material3.Icon(Icons.Default.AddPhotoAlternate, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text(if (photos.isEmpty()) "Choose Photos" else "Change Photos (${photos.size})", fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(14.dp))
            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(22.dp)
            ) {
                if (photos.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            androidx.compose.material3.Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, tint = Purple, modifier = Modifier.size(54.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Your collage starts here", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(6.dp))
                            Text("Choose up to 9 photos to preview your grid.", color = SoftText, fontSize = 13.sp)
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(if (photos.size == 1) 1 else 2),
                        modifier = Modifier.fillMaxSize().padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(photos) { uri ->
                            val bitmap = remember(uri) { loadBitmap(context, uri, 900) }
                            if (bitmap != null) {
                                Image(
                                    bitmap = bitmap.asImageBitmap(),
                                    contentDescription = "Selected photo",
                                    modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)),
                                    contentScale = ContentScale.Crop
                                )
                            } else {
                                Box(Modifier.fillMaxWidth().aspectRatio(1f).background(Color.DarkGray))
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    if (photos.size < 2) {
                        Toast.makeText(context, "Choose at least 2 photos first.", Toast.LENGTH_SHORT).show()
                    } else {
                        val result = createAndSaveCollage(context, photos)
                        if (result != null) {
                            savedUri = result
                            Toast.makeText(context, "Collage saved to Pictures/CollageMaker", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Could not save collage. Please try again.", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.White)
            ) {
                androidx.compose.material3.Icon(Icons.Default.SaveAlt, contentDescription = null, tint = Ink)
                Spacer(Modifier.size(8.dp))
                Text("Create & Save Collage", color = Ink, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    val uri = savedUri
                    if (uri == null) Toast.makeText(context, "Create and save a collage first.", Toast.LENGTH_SHORT).show()
                    else shareImage(context, uri)
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                androidx.compose.material3.Icon(Icons.Default.Share, contentDescription = null)
                Spacer(Modifier.size(8.dp))
                Text("Share Collage")
            }
            Spacer(Modifier.height(8.dp))
            Text("Made for your memories • Up to 9 photos", color = SoftText, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

private fun loadBitmap(context: Context, uri: Uri, maxSize: Int): Bitmap? {
    return try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val original = BitmapFactory.decodeStream(input) ?: return null
            val scale = minOf(maxSize.toFloat() / original.width, maxSize.toFloat() / original.height, 1f)
            if (scale >= 1f) original else Bitmap.createScaledBitmap(
                original, (original.width * scale).toInt().coerceAtLeast(1),
                (original.height * scale).toInt().coerceAtLeast(1), true
            )
        }
    } catch (_: Exception) { null }
}

private fun createAndSaveCollage(context: Context, uris: List<Uri>): Uri? {
    var outputUri: Uri? = null
    try {
        val count = uris.size
        val cols = if (count == 1) 1 else 2
        val rows = (count + cols - 1) / cols
        val cell = 900
        val gap = 12
        val bitmap = Bitmap.createBitmap(cols * cell + (cols + 1) * gap, rows * cell + (rows + 1) * gap, Bitmap.Config.ARGB_8888)
        val canvas = AndroidCanvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        uris.forEachIndexed { index, uri ->
            val photo = loadBitmap(context, uri, 1400) ?: return@forEachIndexed
            val col = index % cols
            val row = index / cols
            val left = gap + col * (cell + gap)
            val top = gap + row * (cell + gap)
            val dst = Rect(left, top, left + cell, top + cell)
            val scale = maxOf(cell.toFloat() / photo.width, cell.toFloat() / photo.height)
            val scaledW = (photo.width * scale).toInt()
            val scaledH = (photo.height * scale).toInt()
            val cropped = Bitmap.createBitmap(photo, ((scaledW - cell) / 2 / scale).toInt().coerceAtLeast(0), ((scaledH - cell) / 2 / scale).toInt().coerceAtLeast(0),
                minOf(photo.width, (cell / scale).toInt().coerceAtLeast(1)), minOf(photo.height, (cell / scale).toInt().coerceAtLeast(1)))
            canvas.drawBitmap(cropped, null, dst, paint)
            if (cropped !== photo) cropped.recycle()
            if (photo !== cropped && !photo.isRecycled) photo.recycle()
        }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "collage_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/CollageMaker")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        outputUri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        context.contentResolver.openOutputStream(outputUri)?.use { out: OutputStream ->
            bitmap.compress(Bitmap.CompressFormat.JPEG, 94, out)
        } ?: return null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(outputUri, values, null, null)
        }
        bitmap.recycle()
        return outputUri
    } catch (_: Exception) {
        outputUri?.let { try { context.contentResolver.delete(it, null, null) } catch (_: Exception) {} }
        return null
    }
}

private fun shareImage(context: Context, uri: Uri) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Share collage"))
}

طريقة سهلة باستعمال GitHub من المتصفح:
1) فصفحة المستودع، ارفع ملف CollageMakerAndroid_Source_v2.zip بوحدو واضغط Commit changes.
2) من صفحة المستودع اختار Add file > Create new file.
3) فاسم الملف كتب بالضبط: .github/workflows/build-from-zip.yml
4) حل الملف GITHUB_BUILD_WORKFLOW_COPY.txt الموجود داخل ZIP وانسخ محتواه كامل، ولصقه فمحرر GitHub.
5) اضغط Commit changes.
6) دخل Actions وشوف عملية Build Collage Maker from ZIP. إلا نجحات، افتح العملية ثم Artifacts وحمّل CollageMaker-debug-apk.
مهم: ملف ZIP خاصو يبقى فالجذر وبنفس الاسم CollageMakerAndroid_Source_v2.zip. هاد APK للتجربة فقط، ماشي AAB موقّع وجاهز للنشر.
